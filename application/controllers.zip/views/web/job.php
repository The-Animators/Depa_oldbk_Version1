<style type="text/css">
    .ui-datepicker-month,.ui-datepicker-year{color: #555;font-weight: normal;border: none}
</style>
<!-- Home Design Inner Pages -->
<div class="ulockd-inner-home">
    <div class="container text-center">
        <div class="row">
            <div class="ulockd-inner-conraimer-details">
                <div class="col-md-12">
                    <h1 class="text-uppercase"><?= $pagetitle;?></h1>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Home Design Inner Pages -->
<?php $this->load->view('web/includes/breadcrumb');?>

<!-- Inner Pages Main Section -->
<section class="ulockd-ip-latest-news">
    <div class="container">
        <div class="row" id="Jobwrapper">
            
            
        </div>
    </div>
</section>