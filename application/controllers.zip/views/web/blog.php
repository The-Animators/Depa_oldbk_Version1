<!-- Home Design Inner Pages -->
<div class="ulockd-inner-home">
    <div class="container text-center">
        <div class="row">
            <div class="ulockd-inner-conraimer-details">
                <div class="col-md-12">
                    <h1 class="text-uppercase"><?= $pagetitle;?></h1>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Home Design Inner Pages -->
<?php $this->load->view('web/includes/breadcrumb');?>

<!-- Inner Pages Main Section -->
<section class="ulockd-fservice">
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 col-lg-6 col-lg-offset-3 text-center">
                <div class="ulockd-dtitle hvr-float-shadow">
                    <h2 class="text-uppercase">Our  <span class="text-thm2">Blogs</span></h2>
                    <!-- <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolorem labore voluptates consequuntur velit necessitatibus maiores fugiat eaque.</p> -->
                </div>
            </div>
        </div>
        <div id="blogwraper">
            <<!-- div class="row">
                <div class="col-sm-6 col-md-4">
                    <figure class="upcoming-event list">
                        <div class="caption">
                            <img class="img-responsive img-whp" src="<?= base_url();?>assets/web/images/event/1.jpg" alt="1.jpg">
                        </div>
                    </figure>
                </div>
                <div class="col-sm-6 col-md-8">
                    <figure class="upcoming-event list">
                        <div class="caption">
                            <div class="event-details ulockd-pad120">
                                <h3 class="event-title">Blog 1</h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Veritatis ipsa ab provident, quis, laborum eligendi facere laboriosam temporibus, maiores dolores autem omnis tempore! Ex quisquam amet, dignissimos veritatis corporis illum? Lorem ipsum dolor sit amet, consectetur adipisicing elit. Veritatis ipsa ab provident, quis, laborum eligendi facere laboriosam temporibus, maiores dolores autem omnis tempore! Ex quisquam amet, dignissimos veritatis corporis illum?</p>
                            </div>
                            <div class="event-footer">
                                <ul class="list-inline">
                                    <li><a href="<?= base_url();?>blog/detail/title" class="btn btn-default ulockd-btn-thm2" title="Event Registration">Read  More</a></li>
                                </ul>
                            </div>
                        </div>
                    </figure>
                </div>
            </div> -->
        </div>
        
    </div>
</section>