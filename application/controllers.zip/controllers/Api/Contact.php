<?php
defined('BASEPATH') or exit('No direct script access allowed');

require APPPATH . './libraries/REST_Controller.php';

class Contact extends REST_Controller{
    private $title;
    public function __construct(){
        parent::__construct();
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate,post-check=0, pre-check=0');
        $this->output->set_header('Pragma: no-cache');
    }

    /*
    1.  HTTP_OK
    2.  HTTP_BAD_REQUEST
    2.  HTTP_NOT_FOUND
    */
    
    public  function index_post(){
        
        $data   = array('status' => false, 'validate' => false, 'message' => array());
        // $verror = array();
        $this->form_validation->set_rules('name', 'Enter Name', 'required|trim');
        $this->form_validation->set_rules('email', 'Enter Email', 'required|trim|valid_email');
        $this->form_validation->set_rules('phone', 'Enter Contact Number', 'required|trim|numeric|min_length[10]|max_length[10]');

        $this->form_validation->set_rules('subject', 'Enter Subject', 'required|trim');
        $this->form_validation->set_rules('message', 'Enter Message', 'required|trim');
        $this->form_validation->set_rules('client', 'Enter Client', 'required|trim');
        $this->form_validation->set_rules('ip', 'Enter IP Address', 'required|trim');
       
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_message('required', ' %s');
        if ($this->form_validation->run()) {
        
            $master['name']          = $this->post('name');
            $master['email']        = $this->post('email');
            $master['phone']     = $this->post('phone');
            $master['subject']      = $this->post('subject');
            $master['message'] = $this->post('message');
            $master['client']   = $this->post('client');
            $master['ip']           = $this->post('ip');
           

            $this->load->library('email'); 
            $config              = array();
            $config['useragent'] = "CodeIgniter";
            $config['mailpath']  = "/usr/bin/sendmail"; // or "/usr/sbin/sendmail"
            //$config['protocol']  = "smtp";
             $config['protocol']  = "mail";
            $config['smtp_host'] = "mail.ekraj.org";
            $config['smtp_port'] = "587";
            $config['smtp_user'] = 'contactdeepa@ekraj.org';
            $config['smtp_pass'] = "_I,jL,Z1MLS)";
            $config['mailtype']  = 'html';
            $config['charset']   = 'utf-8';
            $config['newline']   = "\r\n";
            $config['crlf']      = "\r\n";
            $this->email->initialize($config);
            $this->email->from('contactdeepa@ekraj.org', 'Deepa Village');
           
            $this->email->to('smarshad86@gmail.com');
           // $this->email->to('hppriyanshu1104@gmail.com');
            $this->email->subject('New Contact Detail');
            $body = $this->load->view('email/admin/new-contact', $master, true);
            $this->email->message($body);

            $tst = $this->email->send();
           // print_r($master);
            //print_r($tst);
            //die("Test 70");
            
            if($tst == true){
                $result['status'] = true;
                $result['msg']    = 'Thank you for contact us we will get back to you soon';
            }else{
                $result['status'] = false;
                $result['msg']    = 'Error On Sending Email';
            }
          
            $this->response([
                'status'   => $result['status'],
                'validate' => TRUE,
                'message'  => $result['msg'],
            ], REST_Controller::HTTP_OK);
        } else {
            foreach ($this->post() as $key => $value) {
                $verror[$key] = form_error($key);
            }
            $ab = validation_errors();
            $this->response([
                'status'    => FALSE,
                'validate'  => FALSE,
                'message'   => $verror,
                'ab'   => $ab,
            ], REST_Controller::HTTP_OK);
        }
    }
}